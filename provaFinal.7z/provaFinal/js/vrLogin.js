$(document).ready(function(){

	$("#salvar").click(function(){

		if ($("#nome").val() == "")
		{
			$("#nome").addClass("bd");
		}else{
			$("#nome").removeClass("bd");
		}

		if ($("#sobrenome").val() == "")
		{
			$("#sobrenome").addClass("bd");
		}else{
			$("#sobrenome").removeClass("bd");
		}

		if ($("#email").val() == "")
		{
			$("#email").addClass("bd");
		}else{
			$("#email").removeClass("bd");
		}

		if ($("#mat").val() == "")
		{
			$("#mat").addClass("bd");
		}else{
			$("#mat").removeClass("bd");
		}

		if ($("#user").val() == "")
		{
			$("#user").addClass("bd");
		}else{
			$("#user").removeClass("bd");
		}

		if ($("#senha").val() == "")
		{
			$("#senha").addClass("bd");
		}else{
			$("#senha").removeClass("bd");
		}

		if ($("#confSenha").val() == "")
		{
			$("#confSenha").addClass("bd");
		}else{
			$("#confSenha").removeClass("bd");
		}

		if($("#nome").val() != "" && $("#sobrenome").val() != "" && $("#email").val() != "" && 
		   $("#mat").val() != "" && $("#user").val() != "" && $("#senha").val() != "" && $("#confSenha").val() != "")
		{
			alert("Dados corretamente preenchidos!");
		}else{
			alert("Valores ainda inválidos!"); 
		}

	});

});

function gravarValores(){

	$.ajax({
		type: "POST",
		dataType: "json",
		url: "php/formulario.php",
		data:{
			  nome: $("#nome").val(),
			  sobrenome: $("#sobrenome").val(),
			  email: $("#email").val(),
			  mat: $("#mat").val(),
			  user: $("#user").val(),
			  senha: $("#senha").val(),
			  senha: $("#confSenha").val(),
			 },
		sucess:function(ret){

		}
	
	});

}

	