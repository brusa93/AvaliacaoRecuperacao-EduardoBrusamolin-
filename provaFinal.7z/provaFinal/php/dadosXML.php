<?php

	$xml = new DOMDocument("1.0");

	$xml_cadastro = $xml->createElement("Cadastro");
	$xml_nome = $xml->createElement("Nome");

	$xml_cadastro = $xml->setAttribute("Nome")

	$xml->save("../xml/dados.xml");

?>