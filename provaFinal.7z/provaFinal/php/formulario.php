<?php

	$nome = $_POST["nome"];
	$sobrenome = $_POST["sobrenome"];
	$email = $_POST["email"];
	$mat = $_POST["mat"];
	$user = $_POST["user"];
	$senha = $_POST["senha"];
	$confSenha = $_POST["confSenha"];

	for(){
		
	}


?>